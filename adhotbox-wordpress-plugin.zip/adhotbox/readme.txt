=== AdHotBox ===
Contributors: adhotbox
Tags: advertising, ads, local, monetization, sponsorship
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.2
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Carry a few advertisements and approve every one yourself. Requires a free
account at adhotbox.com. Nothing is shown until you enter your key.

== Description ==

AdHotBox is a small advertising network built for small sites.

Every advertiser appears on your own desk before it can run. You accept it or
you deny it, one click each, and nothing appears on your pages that you have not
agreed to. You can also switch off whole categories and never see them.

**Text or a single image.** Nothing animates, nothing expands, nothing covers
what a reader came for.

**Local first.** When you sign up you say where your readers are. An advertiser
can buy one town, which is why a small site is worth something here — the
hardware store two streets away can reach the people on its streets.

= This plugin requires a third-party service =

**AdHotBox is a Software-as-a-Service advertising network.** This plugin is the
client for it. It does nothing on its own and it will not load anything, contact
anything, or display anything until you have registered at adhotbox.com and
entered your publisher key in the settings.

* Service: **AdHotBox**, https://adhotbox.com
* Terms: https://adhotbox.com/terms.html
* Privacy policy: https://adhotbox.com/privacy.html

= What the plugin loads, and when =

Once, and only once, you have entered a publisher key and left advertising
switched on, the plugin loads one script:

`https://adhotbox.com/box.js`

That script asks our server which advertisement may appear on the page and
renders it. Without a key, the script is never enqueued at all.

= What data is sent, and by whom =

**From your server, at no time.** The plugin sends nothing from your server. It
stores your publisher key and an optional subject in your own WordPress options
table and does nothing else.

**From a visitor's browser, when an advertisement is on the page:**

* the domain of the site the advertisement appeared on
* which advertisement it was
* which slot it was in, and the subject of the page
* whether the advertisement was actually scrolled into view
* whether it was clicked

As with any request to any server on the internet, our server receives the
visitor's IP address and browser user-agent in the connection itself. **These
are not stored and are not written to any record.**

**What is never collected:** no cookie is set. No identifier is stored in the
browser. No profile is built. Nothing follows a visitor to another site. We do
not know who your readers are and we cannot find out.

Advertisers are shown which sites their advertisement ran on, how often, and how
many people clicked. They are never shown anything about a person, because
nothing about a person is recorded.

= What it costs =

The plugin is free and always will be.

If your site is accepted there is a **one-time ten dollar registration fee**. It
pays for a person to look at the site. **It is not refundable and it does not
come off what you earn.** You may instead choose to carry one of our own
advertisements free for six months and pay nothing.

Most networks charge publishers nothing, and that is a fair thing to hold
against us. The reason it exists is that without it every empty site built to
farm advertising applies, and the review is the whole product.

You are told all of this before you are asked for anything, and nothing is
charged at the point of installing this plugin.

= Never accepted, anywhere on the network =

Adult or sexual content. Gambling and betting. Stock promotion and investor
relations advertising. Token sales and crypto offers. Payday and high-interest
lending. Weapons and ammunition. Tobacco and vaping. Get-rich-quick offers,
miracle cures, and advertisements dressed up as news.

Those are refused for every publisher and cannot be switched on.

= Sizes =

Rail 300x600 · Card 300x250 · Inline 728x180 · Leader 970x120 · Banner 600x200 ·
Square 400x400

== Installation ==

1. Apply at https://adhotbox.com/join.html and get your publisher key.
2. Install and activate the plugin.
3. Settings, then AdHotBox, and paste the key. **Until you do this the plugin
   does nothing at all.**
4. Put an advertisement anywhere: the block, the widget, or the shortcode
   `[adhotbox size="card"]`.

== Frequently Asked Questions ==

= Does the plugin do anything before I enter a key? =

No. Without a key it enqueues no script, contacts no server and outputs no
markup. That is deliberate: nothing should reach your visitors before you have
agreed to it.

= Do I have to take every advertisement? =

No, and that is the point of it. **Every advertiser appears in your WordPress
dashboard** under AdHotBox, with the whole advertisement and where the link
goes. Accept or deny, one click each. You may also switch on accept-everything
if you would rather not review them.

= Do I have to leave WordPress to manage it? =

No. Approving advertisers, seeing what is running, and checking what you have
earned all happen in the dashboard. The full desk at adhotbox.com is there if
you want it, and on your phone as well.

= Does it set cookies or track my readers? =

No. There is no cookie and no identifier of any kind. The network records which
advertisement appeared on which site, in which slot, on which subject, and
whether it was seen and clicked. Nothing about a person is recorded.

= Does it slow my site down? =

One small script, loaded at the end of the page. No jQuery, no framework, no
web fonts, no images of its own.

= How do I stop it? =

Uncheck "Show advertisements on this site" in the settings, or deactivate the
plugin. Either stops every slot immediately.

= How am I paid? =

Placements are twenty dollars a month each and you keep five of that per
placement, every month it runs, whatever your traffic does. The rate and what
you have earned are shown on your desk.

== Screenshots ==

1. The settings screen, where the publisher key is entered.
2. An advertisement as it appears on a page.
3. The publisher's desk at adhotbox.com, where each advertiser is accepted or
   denied.

== Changelog ==

= 1.1.0 =
* The desk is now inside WordPress. Accept or deny each advertiser from the
  dashboard instead of going to adhotbox.com.
* Top-level menu with a count of advertisers waiting, and a dashboard widget.
* Running and Denied lists, each reversible with one click.
* Earnings shown in the admin.
* Answers cached briefly so the admin never waits on the network.

= 1.0.0 =
* First release.

== Upgrade Notice ==

= 1.0.0 =
First release.
