/* AdHotBox — the editor block */
( function ( blocks, element, blockEditor, components ) {
	var el = element.createElement;
	var InspectorControls = blockEditor.InspectorControls;
	var PanelBody = components.PanelBody;
	var SelectControl = components.SelectControl;
	var ToggleControl = components.ToggleControl;

	blocks.registerBlockType( 'adhotbox/slot', {
		title: 'AdHotBox',
		icon: 'megaphone',
		category: 'widgets',
		attributes: {
			size: { type: 'string', default: 'card' },
			dark: { type: 'boolean', default: false }
		},

		edit: function ( props ) {
			var a = props.attributes;
			return el( 'div', {},
				el( InspectorControls, {},
					el( PanelBody, { title: 'Advertisement' },
						el( SelectControl, {
							label: 'Size',
							value: a.size,
							options: [
								{ label: 'Rail — 300 x 600',   value: 'rail' },
								{ label: 'Card — 300 x 250',   value: 'card' },
								{ label: 'Inline — 728 x 180', value: 'inline' },
								{ label: 'Leader — 970 x 120', value: 'leader' }
							],
							onChange: function ( v ) { props.setAttributes( { size: v } ); }
						} ),
						el( ToggleControl, {
							label: 'Dark background',
							checked: a.dark,
							onChange: function ( v ) { props.setAttributes( { dark: v } ); }
						} )
					)
				),
				el( 'div', {
					style: {
						border: '1px dashed #c3c8d4',
						borderRadius: '4px',
						padding: '22px 18px',
						textAlign: 'center',
						background: '#f6f7f9',
						font: '13px ui-monospace, Menlo, monospace',
						letterSpacing: '.1em',
						textTransform: 'uppercase',
						color: '#5a6478'
					}
				}, 'AdHotBox — ' + a.size )
			);
		},

		save: function () { return null; }   /* rendered by PHP */
	} );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components );
