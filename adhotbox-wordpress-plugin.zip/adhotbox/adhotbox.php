<?php
/**
 * Plugin Name:       AdHotBox
 * Plugin URI:        https://adhotbox.com
 * Description:       Carry a few advertisements and approve every one yourself, without leaving WordPress. Requires a free account at adhotbox.com; the plugin does nothing until a publisher key is entered. No cookies, no identifiers, nothing that follows a reader anywhere.
 * Version:           1.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.2
 * Author:            AdHotBox
 * Author URI:        https://adhotbox.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       adhotbox
 *
 * THIRD-PARTY SERVICE
 *   Client for AdHotBox, an advertising service at https://adhotbox.com.
 *   Loads one script, https://adhotbox.com/box.js, and only after a publisher
 *   key is entered. With no key it enqueues nothing and outputs nothing.
 *   Terms:   https://adhotbox.com/terms.html
 *   Privacy: https://adhotbox.com/privacy.html
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'ADHOTBOX_VERSION', '1.1.0' );
define( 'ADHOTBOX_SCRIPT',  'https://adhotbox.com/box.js' );
define( 'ADHOTBOX_SITE',    'https://adhotbox.com' );
define( 'ADHOTBOX_API',     'https://adhotbox.realroofers.workers.dev' );

/* ============================================================
   Options
   ============================================================ */

function adhotbox_options() {
	return wp_parse_args( get_option( 'adhotbox_options', array() ), array(
		'pub_key' => '',
		'topic'   => '',
		'enabled' => 1,
		'auto'    => 0,
	) );
}

function adhotbox_key() {
	$o = adhotbox_options();
	return $o['pub_key'];
}

function adhotbox_live() {
	$o = adhotbox_options();
	return ! empty( $o['pub_key'] ) && ! empty( $o['enabled'] );
}

/* ============================================================
   Talking to the service
   ============================================================ */

function adhotbox_get( $args, $ttl = 60 ) {
	$key = adhotbox_key();
	if ( ! $key ) { return null; }

	$args['pub'] = $key;
	$url = ADHOTBOX_API . '?' . http_build_query( $args );

	$cache = 'adhotbox_' . md5( $url );
	if ( $ttl ) {
		$hit = get_transient( $cache );
		if ( false !== $hit ) { return $hit; }
	}

	$res = wp_remote_get( $url, array( 'timeout' => 12 ) );
	if ( is_wp_error( $res ) ) { return null; }
	$body = json_decode( wp_remote_retrieve_body( $res ), true );
	if ( ! is_array( $body ) ) { return null; }

	if ( $ttl ) { set_transient( $cache, $body, $ttl ); }
	return $body;
}

function adhotbox_flush() {
	global $wpdb;
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_adhotbox_%'" );
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_adhotbox_%'" );
}

function adhotbox_queue( $fresh = false ) {
	return adhotbox_get( array( 'queue' => 1 ), $fresh ? 0 : 120 );
}

/* ============================================================
   The menu — top level, with a count, so it is actually seen
   ============================================================ */

add_action( 'admin_menu', 'adhotbox_menu' );
function adhotbox_menu() {

	$waiting = adhotbox_waiting_count();
	$bubble  = $waiting
		? ' <span class="update-plugins count-' . (int) $waiting . '"><span class="update-count">'
			. number_format_i18n( $waiting ) . '</span></span>'
		: '';

	add_menu_page(
		__( 'AdHotBox', 'adhotbox' ),
		__( 'AdHotBox', 'adhotbox' ) . $bubble,
		'manage_options',
		'adhotbox',
		'adhotbox_page',
		'dashicons-megaphone',
		58
	);

	add_submenu_page( 'adhotbox', __( 'Waiting', 'adhotbox' ),
		__( 'Waiting', 'adhotbox' ) . $bubble, 'manage_options', 'adhotbox', 'adhotbox_page' );
	add_submenu_page( 'adhotbox', __( 'Running', 'adhotbox' ),
		__( 'Running', 'adhotbox' ), 'manage_options', 'adhotbox&tab=running', 'adhotbox_page' );
	add_submenu_page( 'adhotbox', __( 'Earnings', 'adhotbox' ),
		__( 'Earnings', 'adhotbox' ), 'manage_options', 'adhotbox&tab=earnings', 'adhotbox_page' );
	add_submenu_page( 'adhotbox', __( 'Settings', 'adhotbox' ),
		__( 'Settings', 'adhotbox' ), 'manage_options', 'adhotbox&tab=settings', 'adhotbox_page' );
}

function adhotbox_waiting_count() {
	if ( ! adhotbox_key() ) { return 0; }
	$q = adhotbox_queue();
	if ( ! $q || empty( $q['campaigns'] ) ) { return 0; }
	$n = 0;
	foreach ( $q['campaigns'] as $c ) {
		if ( isset( $c['verdict'] ) && 'undecided' === $c['verdict'] ) { $n++; }
	}
	return $n;
}

/* ============================================================
   Accept and deny, from inside WordPress
   ============================================================ */

add_action( 'admin_post_adhotbox_decide', 'adhotbox_decide' );
function adhotbox_decide() {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'no' ); }
	check_admin_referer( 'adhotbox_decide' );

	$id      = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	$verdict = isset( $_POST['verdict'] ) ? sanitize_key( $_POST['verdict'] ) : '';
	$back    = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : admin_url( 'admin.php?page=adhotbox' );

	if ( $id && in_array( $verdict, array( 'accept', 'deny' ), true ) ) {
		adhotbox_get( array( 'decide' => $verdict, 'id' => $id ), 0 );
		adhotbox_flush();
		$back = add_query_arg( 'ahb_done', $verdict, $back );
	}
	wp_safe_redirect( $back );
	exit;
}

add_action( 'admin_post_adhotbox_auto', 'adhotbox_auto' );
function adhotbox_auto() {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'no' ); }
	check_admin_referer( 'adhotbox_auto' );
	$on = isset( $_POST['on'] ) && '1' === $_POST['on'] ? 1 : 0;
	adhotbox_get( array( 'decide' => 'auto', 'on' => $on ), 0 );
	adhotbox_flush();
	wp_safe_redirect( admin_url( 'admin.php?page=adhotbox&tab=settings' ) );
	exit;
}

/* ============================================================
   The screens
   ============================================================ */

function adhotbox_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }

	$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'waiting';
	$o   = adhotbox_options();

	echo '<div class="wrap adhotbox">';
	echo '<h1 class="wp-heading-inline">AdHotBox</h1>';

	if ( isset( $_GET['ahb_done'] ) ) {
		$d = sanitize_key( $_GET['ahb_done'] );
		echo '<div class="notice notice-success is-dismissible"><p>'
			. ( 'accept' === $d
				? esc_html__( 'Accepted. It will start appearing in your slots.', 'adhotbox' )
				: esc_html__( 'Denied. It will never appear on this site.', 'adhotbox' ) )
			. '</p></div>';
	}

	/* no key — the only thing to do is get one */
	if ( ! $o['pub_key'] ) { adhotbox_onboard(); echo '</div>'; return; }

	$tabs = array(
		'waiting'  => __( 'Waiting', 'adhotbox' ),
		'running'  => __( 'Running', 'adhotbox' ),
		'earnings' => __( 'Earnings', 'adhotbox' ),
		'place'    => __( 'Place an ad', 'adhotbox' ),
		'settings' => __( 'Settings', 'adhotbox' ),
	);
	echo '<h2 class="nav-tab-wrapper" style="margin:14px 0 20px">';
	foreach ( $tabs as $k => $label ) {
		$n = ( 'waiting' === $k ) ? adhotbox_waiting_count() : 0;
		printf( '<a href="%s" class="nav-tab %s">%s%s</a>',
			esc_url( admin_url( 'admin.php?page=adhotbox&tab=' . $k ) ),
			$tab === $k ? 'nav-tab-active' : '',
			esc_html( $label ),
			$n ? ' <span class="ahb-n">' . (int) $n . '</span>' : ''
		);
	}
	echo '</h2>';

	adhotbox_css();

	if ( 'running' === $tab )       { adhotbox_running(); }
	elseif ( 'earnings' === $tab )  { adhotbox_earnings(); }
	elseif ( 'place' === $tab )     { adhotbox_place(); }
	elseif ( 'settings' === $tab )  { adhotbox_settings(); }
	else                            { adhotbox_waiting(); }

	echo '</div>';
}

/* ---------- no key yet ---------- */

function adhotbox_onboard() {
	?>
	<div class="ahb-onboard">
		<h2><?php esc_html_e( 'Three steps and you are earning', 'adhotbox' ); ?></h2>
		<ol>
			<li><b><?php esc_html_e( 'Apply', 'adhotbox' ); ?></b> —
				<?php esc_html_e( 'free, three minutes. Tell us where your readers are.', 'adhotbox' ); ?>
				<a class="button button-primary" target="_blank" rel="noopener"
				   href="<?php echo esc_url( ADHOTBOX_SITE . '/join.html' ); ?>">
				   <?php esc_html_e( 'Apply at adhotbox.com', 'adhotbox' ); ?></a></li>
			<li><b><?php esc_html_e( 'Paste your key below', 'adhotbox' ); ?></b> —
				<?php esc_html_e( 'we email it when the site is accepted.', 'adhotbox' ); ?></li>
			<li><b><?php esc_html_e( 'Drop an ad block on a page', 'adhotbox' ); ?></b> —
				<?php esc_html_e( 'and accept the advertisers you want, right here.', 'adhotbox' ); ?></li>
		</ol>
		<p class="ahb-quiet"><?php esc_html_e( 'Until a key is entered this plugin loads nothing, contacts nothing and shows nothing.', 'adhotbox' ); ?></p>
	</div>
	<?php
	adhotbox_settings();
}

/* ---------- waiting ---------- */

function adhotbox_waiting() {
	$q = adhotbox_queue( true );
	if ( ! $q || empty( $q['ok'] ) ) {
		echo '<div class="notice notice-error"><p>'
			. esc_html__( 'Could not reach AdHotBox. Check the key in Settings.', 'adhotbox' )
			. '</p></div>';
		return;
	}

	$ads = array();
	foreach ( (array) $q['campaigns'] as $c ) {
		if ( isset( $c['verdict'] ) && 'undecided' === $c['verdict'] ) { $ads[] = $c; }
	}

	if ( ! $ads ) {
		echo '<div class="ahb-empty"><h2>' . esc_html__( 'Nothing waiting.', 'adhotbox' ) . '</h2>'
			. '<p>' . esc_html__( 'New advertisers appear here as they join the network. You will get one email and nothing else.', 'adhotbox' ) . '</p></div>';
		return;
	}

	echo '<p class="ahb-lead">' . sprintf(
		/* translators: %d: number of advertisers */
		esc_html( _n( '%d advertiser is asking to run on your site.', '%d advertisers are asking to run on your site.', count( $ads ), 'adhotbox' ) ),
		count( $ads ) ) . ' <b>' . esc_html__( 'Nothing runs until you say so.', 'adhotbox' ) . '</b></p>';

	$back = admin_url( 'admin.php?page=adhotbox' );
	foreach ( $ads as $a ) {
		?>
		<div class="ahb-card">
			<div class="ahb-head">
				<span class="ahb-adv"><?php echo esc_html( $a['advertiser'] ? $a['advertiser'] : '—' ); ?></span>
				<span class="ahb-cat"><?php echo esc_html( $a['category'] ); ?></span>
				<span class="ahb-pay"><?php
					echo $a['cpm_cents']
						? esc_html( '$' . number_format( $a['cpm_cents'] / 100, 2 ) . ' / 1,000' )
						: esc_html__( 'house', 'adhotbox' ); ?></span>
			</div>
			<p class="ahb-h"><?php echo esc_html( $a['head'] ); ?></p>
			<?php if ( ! empty( $a['body'] ) ) : ?>
				<p class="ahb-b"><?php echo esc_html( $a['body'] ); ?></p>
			<?php endif; ?>
			<p class="ahb-url"><?php echo esc_html( $a['href'] ); ?></p>
			<div class="ahb-acts">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'adhotbox_decide' ); ?>
					<input type="hidden" name="action" value="adhotbox_decide">
					<input type="hidden" name="id" value="<?php echo (int) $a['id']; ?>">
					<input type="hidden" name="back" value="<?php echo esc_attr( $back ); ?>">
					<button class="button button-primary ahb-yes" name="verdict" value="accept">
						<?php esc_html_e( 'Accept', 'adhotbox' ); ?></button>
					<button class="button ahb-no" name="verdict" value="deny">
						<?php esc_html_e( 'Deny', 'adhotbox' ); ?></button>
				</form>
				<a class="ahb-open" href="<?php echo esc_url( $a['href'] ); ?>" target="_blank" rel="noopener nofollow">
					<?php esc_html_e( 'See where it goes', 'adhotbox' ); ?> &#8599;</a>
			</div>
		</div>
		<?php
	}
}

/* ---------- running ---------- */

function adhotbox_running() {
	$q = adhotbox_queue( true );
	if ( ! $q ) { return; }

	$yes = $no = array();
	foreach ( (array) $q['campaigns'] as $c ) {
		if ( 'accept' === $c['verdict'] ) { $yes[] = $c; }
		if ( 'deny'   === $c['verdict'] ) { $no[]  = $c; }
	}

	echo '<h2>' . esc_html__( 'Running on your site', 'adhotbox' ) . '</h2>';
	if ( ! $yes ) {
		echo '<div class="ahb-empty"><p>' . esc_html__( 'Nothing accepted yet.', 'adhotbox' ) . '</p></div>';
	} else {
		echo '<table class="widefat striped ahb-table"><thead><tr>'
			. '<th>' . esc_html__( 'Advertiser', 'adhotbox' ) . '</th>'
			. '<th>' . esc_html__( 'What it says', 'adhotbox' ) . '</th>'
			. '<th>' . esc_html__( 'Category', 'adhotbox' ) . '</th>'
			. '<th></th></tr></thead><tbody>';
		foreach ( $yes as $a ) { adhotbox_row( $a, 'deny', __( 'Stop it', 'adhotbox' ) ); }
		echo '</tbody></table>';
	}

	echo '<h2 style="margin-top:26px">' . esc_html__( 'Denied', 'adhotbox' ) . '</h2>';
	if ( ! $no ) {
		echo '<div class="ahb-empty"><p>' . esc_html__( 'You have not denied anybody.', 'adhotbox' ) . '</p></div>';
	} else {
		echo '<table class="widefat striped ahb-table"><tbody>';
		foreach ( $no as $a ) { adhotbox_row( $a, 'accept', __( 'Let it run', 'adhotbox' ) ); }
		echo '</tbody></table>';
	}
}

function adhotbox_row( $a, $verdict, $label ) {
	$back = admin_url( 'admin.php?page=adhotbox&tab=running' );
	?>
	<tr>
		<td><b><?php echo esc_html( $a['advertiser'] ? $a['advertiser'] : '—' ); ?></b></td>
		<td><?php echo esc_html( $a['head'] ); ?></td>
		<td><?php echo esc_html( $a['category'] ); ?></td>
		<td style="text-align:right">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'adhotbox_decide' ); ?>
				<input type="hidden" name="action" value="adhotbox_decide">
				<input type="hidden" name="id" value="<?php echo (int) $a['id']; ?>">
				<input type="hidden" name="verdict" value="<?php echo esc_attr( $verdict ); ?>">
				<input type="hidden" name="back" value="<?php echo esc_attr( $back ); ?>">
				<button class="button button-small"><?php echo esc_html( $label ); ?></button>
			</form>
		</td>
	</tr>
	<?php
}

/* ---------- earnings ---------- */

function adhotbox_earnings() {
	$q = adhotbox_queue( true );
	$e = ( $q && ! empty( $q['earnings'] ) ) ? $q['earnings'] : array();
	$p = ( $q && ! empty( $q['publisher'] ) ) ? $q['publisher'] : array();

	$share = isset( $e['pub_share_cents'] ) ? $e['pub_share_cents'] : 0;
	?>
	<div class="ahb-nums">
		<div><span class="n"><?php echo esc_html( '$' . number_format( $share / 100, 2 ) ); ?></span>
			<span class="l"><?php esc_html_e( 'Yours', 'adhotbox' ); ?></span></div>
		<div><span class="n"><?php echo esc_html( number_format_i18n( isset( $e['impressions'] ) ? $e['impressions'] : 0 ) ); ?></span>
			<span class="l"><?php esc_html_e( 'Times seen', 'adhotbox' ); ?></span></div>
		<div><span class="n"><?php echo esc_html( number_format_i18n( isset( $e['clicks'] ) ? $e['clicks'] : 0 ) ); ?></span>
			<span class="l"><?php esc_html_e( 'Clicks', 'adhotbox' ); ?></span></div>
		<div><span class="n"><?php echo esc_html( ( isset( $p['rev_share_pct'] ) ? (int) $p['rev_share_pct'] : 0 ) . '%' ); ?></span>
			<span class="l"><?php esc_html_e( 'Your rate', 'adhotbox' ); ?></span></div>
	</div>
	<p class="ahb-quiet"><?php esc_html_e( 'A placement is twenty dollars a month and five of that is yours, every month it runs, whatever your traffic does. There is no minimum before you are paid.', 'adhotbox' ); ?></p>
	<p><a class="button" target="_blank" rel="noopener"
		href="<?php echo esc_url( ADHOTBOX_SITE . '/desk.html' ); ?>">
		<?php esc_html_e( 'Full desk at adhotbox.com', 'adhotbox' ); ?></a></p>
	<?php
}

/* ---------- place an ad ---------- */

function adhotbox_place() {
	?>
	<h2><?php esc_html_e( 'Putting an advertisement on a page', 'adhotbox' ); ?></h2>
	<p class="ahb-lead"><?php esc_html_e( 'Any of these work. Put as many or as few on a page as you like.', 'adhotbox' ); ?></p>

	<div class="ahb-ways">
		<div>
			<h3><?php esc_html_e( 'In the editor', 'adhotbox' ); ?></h3>
			<p><?php esc_html_e( 'Add a block, search for AdHotBox, pick a size. That is it.', 'adhotbox' ); ?></p>
		</div>
		<div>
			<h3><?php esc_html_e( 'In a sidebar', 'adhotbox' ); ?></h3>
			<p><?php esc_html_e( 'Appearance, then Widgets, then AdHotBox.', 'adhotbox' ); ?></p>
		</div>
		<div>
			<h3><?php esc_html_e( 'Anywhere text goes', 'adhotbox' ); ?></h3>
			<p><code>[adhotbox size="card"]</code></p>
		</div>
		<div>
			<h3><?php esc_html_e( 'In a theme file', 'adhotbox' ); ?></h3>
			<p><code>&lt;?php adhotbox_slot( 'rail' ); ?&gt;</code></p>
		</div>
	</div>

	<h3 style="margin-top:24px"><?php esc_html_e( 'The four sizes', 'adhotbox' ); ?></h3>
	<table class="widefat striped ahb-table" style="max-width:640px">
		<tbody>
			<tr><td><b>rail</b></td><td>300 &times; 600</td><td><?php esc_html_e( 'Tall, beside the content', 'adhotbox' ); ?></td></tr>
			<tr><td><b>card</b></td><td>300 &times; 250</td><td><?php esc_html_e( 'A box in a column', 'adhotbox' ); ?></td></tr>
			<tr><td><b>inline</b></td><td>728 &times; 180</td><td><?php esc_html_e( 'Between rows, in the flow', 'adhotbox' ); ?></td></tr>
			<tr><td><b>leader</b></td><td>970 &times; 120</td><td><?php esc_html_e( 'Wide strip, top or bottom', 'adhotbox' ); ?></td></tr>
		</tbody>
	</table>
	<?php
}

/* ---------- settings ---------- */

function adhotbox_settings() {
	$o = adhotbox_options();
	$q = $o['pub_key'] ? adhotbox_queue() : null;
	$p = ( $q && ! empty( $q['publisher'] ) ) ? $q['publisher'] : array();
	?>
	<form method="post" action="options.php">
		<?php settings_fields( 'adhotbox' ); ?>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="ahb_key"><?php esc_html_e( 'Publisher key', 'adhotbox' ); ?></label></th>
				<td>
					<input name="adhotbox_options[pub_key]" id="ahb_key" type="text"
						value="<?php echo esc_attr( $o['pub_key'] ); ?>"
						class="regular-text code" placeholder="pub-xxxxxxxx">
					<p class="description"><?php
						printf(
							/* translators: %s: link */
							esc_html__( 'Emailed to you when your site is accepted. No account yet? %s', 'adhotbox' ),
							'<a href="' . esc_url( ADHOTBOX_SITE . '/join.html' ) . '" target="_blank" rel="noopener">'
							. esc_html__( 'Apply — it is free', 'adhotbox' ) . '</a>'
						); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Advertising', 'adhotbox' ); ?></th>
				<td><label><input name="adhotbox_options[enabled]" type="checkbox" value="1"
					<?php checked( $o['enabled'], 1 ); ?>>
					<?php esc_html_e( 'Show advertisements on this site', 'adhotbox' ); ?></label>
					<p class="description"><?php esc_html_e( 'Turn this off to stop every slot at once without removing anything.', 'adhotbox' ); ?></p></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Where the ads go', 'adhotbox' ); ?></th>
				<td><label><input name="adhotbox_options[auto]" type="checkbox" value="1"
					<?php checked( $o['auto'], 1 ); ?>>
					<?php esc_html_e( 'Place them for me', 'adhotbox' ); ?></label>
					<p class="description"><?php esc_html_e( 'Advertisements appear after the opening paragraphs, in the sidebar if you have one, and above the footer. Nothing to add to any page. Leave this off if you would rather place them yourself with the block, the widget or the shortcode.', 'adhotbox' ); ?></p></td>
			</tr>
			<tr>
				<th scope="row"><label for="ahb_topic"><?php esc_html_e( 'Subject', 'adhotbox' ); ?></label></th>
				<td><input name="adhotbox_options[topic]" id="ahb_topic" type="text"
					value="<?php echo esc_attr( $o['topic'] ); ?>" class="regular-text" placeholder="events">
					<p class="description"><?php esc_html_e( 'Optional. Leave empty to use the subject you gave when you signed up.', 'adhotbox' ); ?></p></td>
			</tr>
		</table>
		<?php submit_button(); ?>
	</form>

	<?php if ( $o['pub_key'] ) : ?>
		<hr>
		<h2><?php esc_html_e( 'How much you review', 'adhotbox' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'adhotbox_auto' ); ?>
			<input type="hidden" name="action" value="adhotbox_auto">
			<?php $auto = ! empty( $p['auto_accept'] ); ?>
			<p><b><?php echo $auto
				? esc_html__( 'Accepting everything.', 'adhotbox' )
				: esc_html__( 'You approve each advertiser.', 'adhotbox' ); ?></b><br>
			<span class="description"><?php echo $auto
				? esc_html__( 'Advertisers start running without asking you. You can still deny any of them afterwards.', 'adhotbox' )
				: esc_html__( 'Nothing runs on your site until you accept it on the Waiting tab.', 'adhotbox' ); ?></span></p>
			<input type="hidden" name="on" value="<?php echo $auto ? '0' : '1'; ?>">
			<button class="button"><?php echo $auto
				? esc_html__( 'Go back to approving each one', 'adhotbox' )
				: esc_html__( 'Accept everything from now on', 'adhotbox' ); ?></button>
		</form>
	<?php endif; ?>

	<hr>
	<h2><?php esc_html_e( 'What this connects to', 'adhotbox' ); ?></h2>
	<p style="max-width:44em"><?php
		printf(
			/* translators: %s: adhotbox.com link */
			esc_html__( 'AdHotBox is an advertising service run at %s. With a key entered and advertising switched on, this plugin loads one script from that domain, which asks the service which advertisement may appear and renders it. With no key it loads nothing and contacts nothing.', 'adhotbox' ),
			'<a href="' . esc_url( ADHOTBOX_SITE ) . '" target="_blank" rel="noopener">adhotbox.com</a>'
		); ?></p>
	<p style="max-width:44em">
		<strong><?php esc_html_e( 'What is sent when an advertisement is on a page:', 'adhotbox' ); ?></strong>
		<?php esc_html_e( 'the domain of this site, which advertisement it was, which slot, the subject of the page, whether it was scrolled into view, and whether it was clicked.', 'adhotbox' ); ?>
		<strong><?php esc_html_e( 'No cookie is set and no identifier is stored.', 'adhotbox' ); ?></strong>
		<?php esc_html_e( 'Nothing about a reader is recorded and nothing follows anyone to another site.', 'adhotbox' ); ?></p>
	<p>
		<a href="<?php echo esc_url( ADHOTBOX_SITE . '/privacy.html' ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Privacy policy', 'adhotbox' ); ?></a> &middot;
		<a href="<?php echo esc_url( ADHOTBOX_SITE . '/terms.html' ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Terms', 'adhotbox' ); ?></a>
	</p>
	<?php
}

add_action( 'admin_init', 'adhotbox_register_settings' );
function adhotbox_register_settings() {
	register_setting( 'adhotbox', 'adhotbox_options', array(
		'sanitize_callback' => 'adhotbox_sanitize',
	) );
}
function adhotbox_sanitize( $in ) {
	adhotbox_flush();
	return array(
		'pub_key' => isset( $in['pub_key'] ) ? sanitize_text_field( $in['pub_key'] ) : '',
		'topic'   => isset( $in['topic'] )   ? sanitize_key( $in['topic'] )         : '',
		'enabled' => empty( $in['enabled'] ) ? 0 : 1,
		'auto'    => empty( $in['auto'] )    ? 0 : 1,
	);
}

/* ============================================================
   The dashboard widget — so it is seen without going looking
   ============================================================ */

add_action( 'wp_dashboard_setup', 'adhotbox_dash' );
function adhotbox_dash() {
	if ( ! current_user_can( 'manage_options' ) || ! adhotbox_key() ) { return; }
	wp_add_dashboard_widget( 'adhotbox_dash', __( 'AdHotBox', 'adhotbox' ), 'adhotbox_dash_widget' );
}

function adhotbox_dash_widget() {
	$q = adhotbox_queue();
	$n = adhotbox_waiting_count();
	$e = ( $q && ! empty( $q['earnings'] ) ) ? $q['earnings'] : array();
	$share = isset( $e['pub_share_cents'] ) ? $e['pub_share_cents'] : 0;

	adhotbox_css();
	echo '<div class="ahb-nums small">';
	echo '<div><span class="n">' . (int) $n . '</span><span class="l">' . esc_html__( 'Waiting', 'adhotbox' ) . '</span></div>';
	echo '<div><span class="n">$' . esc_html( number_format( $share / 100, 2 ) ) . '</span><span class="l">' . esc_html__( 'Yours', 'adhotbox' ) . '</span></div>';
	echo '<div><span class="n">' . esc_html( number_format_i18n( isset( $e['impressions'] ) ? $e['impressions'] : 0 ) ) . '</span><span class="l">' . esc_html__( 'Seen', 'adhotbox' ) . '</span></div>';
	echo '</div>';

	if ( $n ) {
		echo '<p><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=adhotbox' ) ) . '">'
			. esc_html( sprintf(
				/* translators: %d: number waiting */
				_n( 'Review %d advertiser', 'Review %d advertisers', $n, 'adhotbox' ), $n ) )
			. '</a></p>';
	} else {
		echo '<p class="ahb-quiet">' . esc_html__( 'Nothing waiting on you.', 'adhotbox' ) . '</p>';
	}
}

/* ============================================================
   Styles for the admin screens
   ============================================================ */

function adhotbox_css() {
	static $done = false;
	if ( $done ) { return; }
	$done = true;
	?>
	<style>
	.adhotbox .ahb-lead{font-size:15px;max-width:62em;margin:0 0 16px}
	.adhotbox .ahb-quiet{color:#646970;max-width:62em}
	.ahb-n{background:#d63638;color:#fff;border-radius:9px;padding:1px 7px;font-size:11px;margin-left:4px}
	.ahb-card{background:#fff;border:1px solid #dcdcde;border-left:4px solid #FF4A00;
		border-radius:4px;padding:16px 18px;margin:0 0 12px;max-width:800px}
	.ahb-head{display:flex;gap:10px;align-items:baseline;flex-wrap:wrap;margin-bottom:8px}
	.ahb-adv{font-weight:700;font-size:15px}
	.ahb-cat{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#646970;
		background:#f0f0f1;border-radius:3px;padding:2px 7px}
	.ahb-pay{margin-left:auto;font-size:12px;color:#646970;font-family:monospace}
	.ahb-h{font-size:17px;font-weight:600;margin:0 0 5px}
	.ahb-b{margin:0 0 8px;color:#3c434a;max-width:60em}
	.ahb-url{font:12px monospace;color:#646970;margin:0 0 12px;word-break:break-all}
	.ahb-acts{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
	.ahb-acts form{display:flex;gap:8px}
	.ahb-yes{background:#00a32a!important;border-color:#00a32a!important}
	.ahb-no{color:#d63638!important;border-color:#d6c2c3!important}
	.ahb-open{margin-left:auto;font-size:12px;color:#646970;text-decoration:none}
	.ahb-empty{background:#fff;border:1px solid #dcdcde;border-radius:4px;
		padding:26px;max-width:800px;text-align:center}
	.ahb-empty h2{margin:0 0 6px}
	.ahb-empty p{color:#646970;margin:0}
	.ahb-nums{display:flex;gap:1px;background:#dcdcde;border:1px solid #dcdcde;
		border-radius:4px;overflow:hidden;max-width:800px;margin:0 0 16px}
	.ahb-nums div{flex:1;background:#fff;padding:18px 14px;text-align:center}
	.ahb-nums .n{display:block;font:700 26px/1 monospace}
	.ahb-nums .l{display:block;font-size:11px;text-transform:uppercase;
		letter-spacing:.1em;color:#646970;margin-top:7px}
	.ahb-nums.small .n{font-size:20px}
	.ahb-ways{display:grid;gap:14px;max-width:800px}
	@media(min-width:782px){.ahb-ways{grid-template-columns:1fr 1fr}}
	.ahb-ways div{background:#fff;border:1px solid #dcdcde;border-radius:4px;padding:14px 16px}
	.ahb-ways h3{margin:0 0 5px;font-size:14px}
	.ahb-ways p{margin:0;color:#646970;font-size:13.5px}
	.ahb-onboard{background:#fff;border:1px solid #dcdcde;border-left:4px solid #FF4A00;
		border-radius:4px;padding:20px 24px;max-width:800px;margin:14px 0 22px}
	.ahb-onboard h2{margin:0 0 12px}
	.ahb-onboard ol{margin:0 0 12px;padding-left:1.2em}
	.ahb-onboard li{margin-bottom:10px}
	.ahb-onboard .button{margin-left:8px}
	.ahb-table td{vertical-align:middle}
	</style>
	<?php
}

/* ============================================================
   The front end
   ============================================================ */

add_action( 'wp_enqueue_scripts', 'adhotbox_enqueue' );
function adhotbox_enqueue() {
	if ( ! adhotbox_live() ) { return; }
	wp_enqueue_script( 'adhotbox', ADHOTBOX_SCRIPT, array(), ADHOTBOX_VERSION, true );
}

/* let the script place the slots itself, if they asked for that */
add_filter( 'script_loader_tag', 'adhotbox_auto_attr', 10, 3 );
function adhotbox_auto_attr( $tag, $handle, $src ) {
	if ( 'adhotbox' !== $handle ) { return $tag; }
	$o = adhotbox_options();
	if ( empty( $o['auto'] ) ) { return $tag; }
	return str_replace( ' src=', ' data-auto src=', $tag );
}

add_action( 'wp_head', 'adhotbox_head' );
function adhotbox_head() {
	if ( ! adhotbox_live() ) { return; }
	$o = adhotbox_options();
	if ( ! empty( $o['topic'] ) ) {
		echo '<meta name="ad-topic" content="' . esc_attr( $o['topic'] ) . '">' . "\n";
	}
}

function adhotbox_markup( $size = 'card', $dark = false ) {
	if ( ! adhotbox_live() ) { return ''; }
	$allowed = array( 'rail', 'card', 'inline', 'leader' );
	$size    = in_array( $size, $allowed, true ) ? $size : 'card';
	return '<div class="adhotbox-slot" data-ad="' . esc_attr( $size ) . '"'
		. ( $dark ? ' data-dark="1"' : '' ) . '></div>';
}

function adhotbox_slot( $size = 'card', $dark = false ) {
	echo adhotbox_markup( $size, $dark ); // phpcs:ignore WordPress.Security.EscapeOutput
}

add_shortcode( 'adhotbox', 'adhotbox_shortcode' );
function adhotbox_shortcode( $atts ) {
	$a = shortcode_atts( array( 'size' => 'card', 'dark' => '' ), $atts, 'adhotbox' );
	return adhotbox_markup( $a['size'], ! empty( $a['dark'] ) );
}

/* ---------- block ---------- */

add_action( 'init', 'adhotbox_block' );
function adhotbox_block() {
	if ( ! function_exists( 'register_block_type' ) ) { return; }
	wp_register_script( 'adhotbox-block', plugins_url( 'block.js', __FILE__ ),
		array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components' ),
		ADHOTBOX_VERSION, true );
	register_block_type( 'adhotbox/slot', array(
		'editor_script'   => 'adhotbox-block',
		'attributes'      => array(
			'size' => array( 'type' => 'string',  'default' => 'card' ),
			'dark' => array( 'type' => 'boolean', 'default' => false ),
		),
		'render_callback' => 'adhotbox_block_render',
	) );
}
function adhotbox_block_render( $attr ) {
	return adhotbox_markup(
		isset( $attr['size'] ) ? $attr['size'] : 'card',
		! empty( $attr['dark'] )
	);
}

/* ---------- widget ---------- */

add_action( 'widgets_init', function () { register_widget( 'AdHotBox_Widget' ); } );

class AdHotBox_Widget extends WP_Widget {
	public function __construct() {
		parent::__construct( 'adhotbox_widget', __( 'AdHotBox', 'adhotbox' ),
			array( 'description' => __( 'One advertisement you have accepted.', 'adhotbox' ) ) );
	}
	public function widget( $args, $instance ) {
		$out = adhotbox_markup( ! empty( $instance['size'] ) ? $instance['size'] : 'card' );
		if ( ! $out ) { return; }
		echo $args['before_widget']; // phpcs:ignore
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; // phpcs:ignore
		}
		echo $out; // phpcs:ignore
		echo $args['after_widget']; // phpcs:ignore
	}
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : '';
		$size  = isset( $instance['size'] )  ? $instance['size']  : 'card';
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
			<?php esc_html_e( 'Heading (optional)', 'adhotbox' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
				type="text" value="<?php echo esc_attr( $title ); ?>"></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'size' ) ); ?>">
			<?php esc_html_e( 'Size', 'adhotbox' ); ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'size' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'size' ) ); ?>">
				<?php foreach ( array(
					'rail'   => 'Rail — 300 x 600',
					'card'   => 'Card — 300 x 250',
					'inline' => 'Inline — 728 x 180',
					'leader' => 'Leader — 970 x 120',
				) as $k => $label ) : ?>
					<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $size, $k ); ?>>
						<?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select></p>
		<?php
	}
	public function update( $new, $old ) {
		return array(
			'title' => sanitize_text_field( isset( $new['title'] ) ? $new['title'] : '' ),
			'size'  => sanitize_key( isset( $new['size'] ) ? $new['size'] : 'card' ),
		);
	}
}

/* ============================================================
   A nudge, dismissible, only on the plugins screen
   ============================================================ */

add_action( 'admin_notices', 'adhotbox_notice' );
function adhotbox_notice() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	if ( adhotbox_key() ) { return; }
	if ( get_user_meta( get_current_user_id(), 'adhotbox_hide_notice', true ) ) { return; }
	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->id, array( 'plugins', 'plugins-network' ), true ) ) { return; }

	$hide = wp_nonce_url( add_query_arg( 'adhotbox_hide', '1' ), 'adhotbox_hide', 'adhotbox_nonce' );
	echo '<div class="notice notice-info is-dismissible"><p><strong>AdHotBox</strong> — '
		. esc_html__( 'add your publisher key to start showing advertisements. Until you do, this plugin does nothing.', 'adhotbox' )
		. ' <a href="' . esc_url( admin_url( 'admin.php?page=adhotbox&tab=settings' ) ) . '">'
		. esc_html__( 'Settings', 'adhotbox' ) . '</a>'
		. ' &middot; <a href="' . esc_url( $hide ) . '">'
		. esc_html__( 'do not show this again', 'adhotbox' ) . '</a></p></div>';
}

add_action( 'admin_init', 'adhotbox_maybe_hide_notice' );
function adhotbox_maybe_hide_notice() {
	if ( empty( $_GET['adhotbox_hide'] ) ) { return; }
	if ( ! isset( $_GET['adhotbox_nonce'] )
		|| ! wp_verify_nonce( sanitize_key( wp_unslash( $_GET['adhotbox_nonce'] ) ), 'adhotbox_hide' ) ) {
		return;
	}
	update_user_meta( get_current_user_id(), 'adhotbox_hide_notice', 1 );
}

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'adhotbox_action_links' );
function adhotbox_action_links( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=adhotbox' ) ) . '">'
		. esc_html__( 'AdHotBox', 'adhotbox' ) . '</a>' );
	return $links;
}
