<?php
/**
 * Plugin Name:       AdHotBox
 * Plugin URI:        https://adhotbox.com
 * Description:       Carry a few advertisements and keep control of every one. You accept or deny each advertiser yourself, one click each, on your own desk at adhotbox.com. Requires a free account at adhotbox.com; the plugin does nothing until a publisher key is entered. No cookies, no identifiers, nothing that follows a reader anywhere.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.2
 * Author:            AdHotBox
 * Author URI:        https://adhotbox.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       adhotbox
 *
 * THIRD-PARTY SERVICE
 *   This plugin is the client for AdHotBox, an advertising service at
 *   https://adhotbox.com. It loads one script, https://adhotbox.com/box.js,
 *   and only after a publisher key has been entered. With no key it enqueues
 *   nothing, contacts nothing and outputs nothing.
 *   Terms:   https://adhotbox.com/terms.html
 *   Privacy: https://adhotbox.com/privacy.html
 *
 * HOW TO USE
 *   1. Settings → AdHotBox. Paste the publisher key you were given.
 *   2. Put an advertisement anywhere:
 *        - Shortcode:  [adhotbox size="card"]
 *        - Block:      search "AdHotBox" in the block inserter
 *        - Widget:     Appearance → Widgets → AdHotBox
 *        - In a theme: <?php adhotbox_slot( 'rail' ); ?>
 *
 * SIZES  rail 300x600 · card 300x250 · inline 728x180 · leader 970x120
 *
 * WHAT IT LOADS
 *   One small script from adhotbox.com. No jQuery, no cookies, no tracking
 *   of your readers. The script asks the server what may run on your site
 *   and renders it.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'ADHOTBOX_VERSION', '1.0.0' );
define( 'ADHOTBOX_SCRIPT', 'https://adhotbox.com/box.js' );
define( 'ADHOTBOX_SITE',   'https://adhotbox.com' );

/* ============================================================
   Settings
   ============================================================ */

function adhotbox_options() {
	$o = get_option( 'adhotbox_options', array() );
	return wp_parse_args( $o, array(
		'pub_key'  => '',
		'topic'    => '',
		'enabled'  => 1,
	) );
}

add_action( 'admin_menu', 'adhotbox_menu' );
function adhotbox_menu() {
	add_options_page(
		__( 'AdHotBox', 'adhotbox' ),
		__( 'AdHotBox', 'adhotbox' ),
		'manage_options',
		'adhotbox',
		'adhotbox_settings_page'
	);
}

add_action( 'admin_init', 'adhotbox_register_settings' );
function adhotbox_register_settings() {
	register_setting( 'adhotbox', 'adhotbox_options', array(
		'sanitize_callback' => 'adhotbox_sanitize',
	) );
}

function adhotbox_sanitize( $in ) {
	return array(
		'pub_key' => isset( $in['pub_key'] ) ? sanitize_text_field( $in['pub_key'] ) : '',
		'topic'   => isset( $in['topic'] )   ? sanitize_key( $in['topic'] )         : '',
		'enabled' => empty( $in['enabled'] ) ? 0 : 1,
	);
}

function adhotbox_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$o = adhotbox_options();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'AdHotBox', 'adhotbox' ); ?></h1>

		<p style="max-width:44em">
			<?php esc_html_e( 'You accept or deny every advertiser yourself, one click each, on your desk at adhotbox.com. Nothing appears on this site that you have not agreed to.', 'adhotbox' ); ?>
		</p>

		<form method="post" action="options.php">
			<?php settings_fields( 'adhotbox' ); ?>
			<table class="form-table" role="presentation">

				<tr>
					<th scope="row"><label for="ahb_key"><?php esc_html_e( 'Publisher key', 'adhotbox' ); ?></label></th>
					<td>
						<input name="adhotbox_options[pub_key]" id="ahb_key" type="text"
							value="<?php echo esc_attr( $o['pub_key'] ); ?>"
							class="regular-text" placeholder="pub-xxxxxxxx">
						<p class="description">
							<?php
							printf(
								/* translators: %s: link to adhotbox.com */
								esc_html__( 'Given to you when your site was accepted. Do not have one? Apply at %s.', 'adhotbox' ),
								'<a href="' . esc_url( ADHOTBOX_SITE . '/join.html' ) . '" target="_blank" rel="noopener">adhotbox.com</a>'
							);
							?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><label for="ahb_topic"><?php esc_html_e( 'Subject', 'adhotbox' ); ?></label></th>
					<td>
						<input name="adhotbox_options[topic]" id="ahb_topic" type="text"
							value="<?php echo esc_attr( $o['topic'] ); ?>"
							class="regular-text" placeholder="events">
						<p class="description">
							<?php esc_html_e( 'Optional. Leave empty to use the subject you gave when you signed up.', 'adhotbox' ); ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'Advertising', 'adhotbox' ); ?></th>
					<td>
						<label>
							<input name="adhotbox_options[enabled]" type="checkbox" value="1"
								<?php checked( $o['enabled'], 1 ); ?>>
							<?php esc_html_e( 'Show advertisements on this site', 'adhotbox' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Turn this off to stop every slot at once without removing anything.', 'adhotbox' ); ?>
						</p>
					</td>
				</tr>

			</table>
			<?php submit_button(); ?>
		</form>

		<hr>

		<h2><?php esc_html_e( 'What this connects to', 'adhotbox' ); ?></h2>
		<p style="max-width:44em">
			<?php
			printf(
				/* translators: %s: adhotbox.com link */
				esc_html__( 'AdHotBox is an advertising service run at %s. With a key entered and advertising switched on, this plugin loads one script from that domain, which asks the service which advertisement may appear and renders it. With no key it loads nothing and contacts nothing.', 'adhotbox' ),
				'<a href="' . esc_url( ADHOTBOX_SITE ) . '" target="_blank" rel="noopener">adhotbox.com</a>'
			);
			?>
		</p>
		<p style="max-width:44em">
			<strong><?php esc_html_e( 'What is sent when an advertisement is on a page:', 'adhotbox' ); ?></strong>
			<?php esc_html_e( 'the domain of this site, which advertisement it was, which slot, the subject of the page, whether it was scrolled into view, and whether it was clicked.', 'adhotbox' ); ?>
			<strong><?php esc_html_e( 'No cookie is set and no identifier is stored.', 'adhotbox' ); ?></strong>
			<?php esc_html_e( 'Nothing about a reader is recorded and nothing follows anyone to another site.', 'adhotbox' ); ?>
		</p>
		<p>
			<a href="<?php echo esc_url( ADHOTBOX_SITE . '/privacy.html' ); ?>" target="_blank" rel="noopener">
				<?php esc_html_e( 'Privacy policy', 'adhotbox' ); ?></a> &middot;
			<a href="<?php echo esc_url( ADHOTBOX_SITE . '/terms.html' ); ?>" target="_blank" rel="noopener">
				<?php esc_html_e( 'Terms', 'adhotbox' ); ?></a>
		</p>

		<hr>

		<h2><?php esc_html_e( 'Putting an advertisement on a page', 'adhotbox' ); ?></h2>
		<p><?php esc_html_e( 'Any of these work. Sizes are rail, card, inline and leader.', 'adhotbox' ); ?></p>
		<p><code>[adhotbox size="card"]</code></p>
		<p><?php esc_html_e( 'Or add the AdHotBox block in the editor, or the AdHotBox widget under Appearance.', 'adhotbox' ); ?></p>
		<p><?php esc_html_e( 'In a theme template:', 'adhotbox' ); ?>
			<code>&lt;?php adhotbox_slot( 'rail' ); ?&gt;</code></p>

		<hr>
		<h2><?php esc_html_e( 'Your desk', 'adhotbox' ); ?></h2>
		<p>
			<a class="button" target="_blank" rel="noopener"
			   href="<?php echo esc_url( ADHOTBOX_SITE . '/desk.html' ); ?>">
				<?php esc_html_e( 'Open my desk at adhotbox.com', 'adhotbox' ); ?>
			</a>
		</p>
		<p class="description" style="max-width:44em">
			<?php esc_html_e( 'Accept or deny each advertiser, switch off whole categories, and see what you have earned. Adult content, gambling, stock promotion, payday lending, weapons, tobacco and get-rich-quick offers are refused across the whole network and can never reach your desk.', 'adhotbox' ); ?>
		</p>
	</div>
	<?php
}

/* ============================================================
   The script
   ============================================================ */

add_action( 'wp_enqueue_scripts', 'adhotbox_enqueue' );
function adhotbox_enqueue() {
	$o = adhotbox_options();
	if ( empty( $o['pub_key'] ) || empty( $o['enabled'] ) ) { return; }
	wp_enqueue_script( 'adhotbox', ADHOTBOX_SCRIPT, array(), ADHOTBOX_VERSION, true );
}

/* the subject, if one was set, so campaigns can target it */
add_action( 'wp_head', 'adhotbox_head' );
function adhotbox_head() {
	$o = adhotbox_options();
	if ( empty( $o['pub_key'] ) || empty( $o['enabled'] ) ) { return; }
	if ( ! empty( $o['topic'] ) ) {
		echo '<meta name="ad-topic" content="' . esc_attr( $o['topic'] ) . '">' . "\n";
	}
}

/* ============================================================
   The slot
   ============================================================ */

function adhotbox_markup( $size = 'card', $dark = false ) {
	$o = adhotbox_options();
	if ( empty( $o['pub_key'] ) || empty( $o['enabled'] ) ) { return ''; }

	$allowed = array( 'rail', 'card', 'inline', 'leader' );
	$size    = in_array( $size, $allowed, true ) ? $size : 'card';

	return '<div class="adhotbox-slot" data-ad="' . esc_attr( $size ) . '"'
		. ( $dark ? ' data-dark="1"' : '' ) . '></div>';
}

function adhotbox_slot( $size = 'card', $dark = false ) {
	echo adhotbox_markup( $size, $dark ); // phpcs:ignore WordPress.Security.EscapeOutput
}

add_shortcode( 'adhotbox', 'adhotbox_shortcode' );
function adhotbox_shortcode( $atts ) {
	$a = shortcode_atts( array(
		'size' => 'card',
		'dark' => '',
	), $atts, 'adhotbox' );
	return adhotbox_markup( $a['size'], ! empty( $a['dark'] ) );
}

/* ============================================================
   The block
   ============================================================ */

add_action( 'init', 'adhotbox_block' );
function adhotbox_block() {
	if ( ! function_exists( 'register_block_type' ) ) { return; }

	wp_register_script(
		'adhotbox-block',
		plugins_url( 'block.js', __FILE__ ),
		array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components' ),
		ADHOTBOX_VERSION,
		true
	);

	register_block_type( 'adhotbox/slot', array(
		'editor_script'   => 'adhotbox-block',
		'attributes'      => array(
			'size' => array( 'type' => 'string', 'default' => 'card' ),
			'dark' => array( 'type' => 'boolean', 'default' => false ),
		),
		'render_callback' => 'adhotbox_block_render',
	) );
}

function adhotbox_block_render( $attr ) {
	$size = isset( $attr['size'] ) ? $attr['size'] : 'card';
	$dark = ! empty( $attr['dark'] );
	return adhotbox_markup( $size, $dark );
}

/* ============================================================
   The widget
   ============================================================ */

add_action( 'widgets_init', function () { register_widget( 'AdHotBox_Widget' ); } );

class AdHotBox_Widget extends WP_Widget {

	public function __construct() {
		parent::__construct(
			'adhotbox_widget',
			__( 'AdHotBox', 'adhotbox' ),
			array( 'description' => __( 'One advertisement you have accepted.', 'adhotbox' ) )
		);
	}

	public function widget( $args, $instance ) {
		$size = ! empty( $instance['size'] ) ? $instance['size'] : 'card';
		$out  = adhotbox_markup( $size );
		if ( ! $out ) { return; }
		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; // phpcs:ignore
		}
		echo $out; // phpcs:ignore WordPress.Security.EscapeOutput
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : '';
		$size  = isset( $instance['size'] )  ? $instance['size']  : 'card';
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
				<?php esc_html_e( 'Heading (optional)', 'adhotbox' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
				type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'size' ) ); ?>">
				<?php esc_html_e( 'Size', 'adhotbox' ); ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'size' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'size' ) ); ?>">
				<?php foreach ( array(
					'rail'   => 'Rail — 300 x 600',
					'card'   => 'Card — 300 x 250',
					'inline' => 'Inline — 728 x 180',
					'leader' => 'Leader — 970 x 120',
				) as $k => $label ) : ?>
					<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $size, $k ); ?>>
						<?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<?php
	}

	public function update( $new, $old ) {
		return array(
			'title' => sanitize_text_field( isset( $new['title'] ) ? $new['title'] : '' ),
			'size'  => sanitize_key( isset( $new['size'] ) ? $new['size'] : 'card' ),
		);
	}
}

/* ============================================================
   A nudge on the plugins screen if no key is set
   ============================================================ */

add_action( 'admin_notices', 'adhotbox_notice' );
function adhotbox_notice() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$o = adhotbox_options();
	if ( ! empty( $o['pub_key'] ) ) { return; }
	if ( get_user_meta( get_current_user_id(), 'adhotbox_hide_notice', true ) ) { return; }
	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->id, array( 'plugins', 'plugins-network' ), true ) ) { return; }

	$hide = wp_nonce_url(
		add_query_arg( 'adhotbox_hide', '1' ),
		'adhotbox_hide',
		'adhotbox_nonce'
	);

	echo '<div class="notice notice-info is-dismissible"><p><strong>AdHotBox</strong> — '
		. esc_html__( 'add your publisher key to start showing advertisements. Until you do, this plugin does nothing.', 'adhotbox' )
		. ' <a href="' . esc_url( admin_url( 'options-general.php?page=adhotbox' ) ) . '">'
		. esc_html__( 'Settings', 'adhotbox' ) . '</a>'
		. ' &middot; <a href="' . esc_url( $hide ) . '">'
		. esc_html__( 'do not show this again', 'adhotbox' ) . '</a></p></div>';
}

add_action( 'admin_init', 'adhotbox_maybe_hide_notice' );
function adhotbox_maybe_hide_notice() {
	if ( empty( $_GET['adhotbox_hide'] ) ) { return; }
	if ( ! isset( $_GET['adhotbox_nonce'] )
		|| ! wp_verify_nonce( sanitize_key( wp_unslash( $_GET['adhotbox_nonce'] ) ), 'adhotbox_hide' ) ) {
		return;
	}
	update_user_meta( get_current_user_id(), 'adhotbox_hide_notice', 1 );
}

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'adhotbox_action_links' );
function adhotbox_action_links( $links ) {
	array_unshift( $links, '<a href="'
		. esc_url( admin_url( 'options-general.php?page=adhotbox' ) ) . '">'
		. esc_html__( 'Settings', 'adhotbox' ) . '</a>' );
	return $links;
}
